-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 18 2019 г., 20:10
-- Версия сервера: 10.1.37-MariaDB
-- Версия PHP: 7.1.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `new_bd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `favouriteday`
--

CREATE TABLE `favouriteday` (
  `id` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `favouriteday`
--

INSERT INTO `favouriteday` (`id`, `day`, `month`, `year`) VALUES
(1, 2, 10, 1965);

-- --------------------------------------------------------

--
-- Структура таблицы `nobel_country`
--

CREATE TABLE `nobel_country` (
  `id_country` int(11) NOT NULL,
  `country` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `nobel_science`
--

CREATE TABLE `nobel_science` (
  `id_science` int(11) NOT NULL,
  `science` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `nobel_scientist`
--

CREATE TABLE `nobel_scientist` (
  `name_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `secondname` varchar(50) NOT NULL,
  `science` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `nobel_year`
--

CREATE TABLE `nobel_year` (
  `year_id` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`, `age`, `email`) VALUES
(1, 'Ніколай', 62, 'memdf@ffge.net'),
(2, 'гы', 6, 'asd@тест.укр'),
(3, 'name2', 26, 'asd@ffg.net'),
(4, 'Іванко', 0, 'asd@тест.укр'),
(5, 'Моє ім\'я', 46, 'asd@тест.укр'),
(6, 'тест 2', 16, 'asd@тест.укр'),
(7, 'Ніколай Іванович', 35, 'mmdf@ffg.net'),
(8, 'ert', 15, 'lolaambers@gmail.com');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `login` int(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `user_datail_info`
--

CREATE TABLE `user_datail_info` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `detail` varchar(50) NOT NULL,
  `addres` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_datail_info`
--

INSERT INTO `user_datail_info` (`id`, `user_id`, `detail`, `addres`) VALUES
(1, 1, 'читатель', 'Киев'),
(2, 3, 'библиотекарь', 'Одесса'),
(3, 4, 'рабочий', 'Львов'),
(4, 9, 'студент', 'Киев'),
(5, 6, 'машинист', 'Житомир'),
(6, 4, 'гитарист', 'Буча'),
(7, 5, 'басист', 'Харьков');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `favouriteday`
--
ALTER TABLE `favouriteday`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `nobel_country`
--
ALTER TABLE `nobel_country`
  ADD PRIMARY KEY (`id_country`);

--
-- Индексы таблицы `nobel_science`
--
ALTER TABLE `nobel_science`
  ADD PRIMARY KEY (`id_science`);

--
-- Индексы таблицы `nobel_scientist`
--
ALTER TABLE `nobel_scientist`
  ADD PRIMARY KEY (`name_id`);

--
-- Индексы таблицы `nobel_year`
--
ALTER TABLE `nobel_year`
  ADD PRIMARY KEY (`year_id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user_datail_info`
--
ALTER TABLE `user_datail_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `favouriteday`
--
ALTER TABLE `favouriteday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `nobel_country`
--
ALTER TABLE `nobel_country`
  MODIFY `id_country` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `nobel_science`
--
ALTER TABLE `nobel_science`
  MODIFY `id_science` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `nobel_scientist`
--
ALTER TABLE `nobel_scientist`
  MODIFY `name_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `nobel_year`
--
ALTER TABLE `nobel_year`
  MODIFY `year_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `user_datail_info`
--
ALTER TABLE `user_datail_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
