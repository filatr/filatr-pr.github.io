-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Авг 04 2019 г., 13:49
-- Версия сервера: 10.1.38-MariaDB
-- Версия PHP: 7.2.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `new_bd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `contact_list`
--

CREATE TABLE `contact_list` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tel` varchar(100) NOT NULL,
  `info` text NOT NULL,
  `img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `contact_list`
--

INSERT INTO `contact_list` (`id`, `name`, `tel`, `info`, `img`) VALUES
(1, 'Иванов', '+38000-123-45-60', 'А где тут чай', '../images/contact_list/001.png'),
(2, 'Петров', '+38000-123-45-68', 'Понедельник это круто', '../images/contact_list/002.png'),
(3, 'Сидоров', '+38012-123-45-67', 'Троещина рулит', '../images/contact_list/003.png'),
(4, 'Вениямин', '+38013-223-45-67', 'With love to Ukraine', '../images/contact_list/004.png'),
(5, 'Валерий', '+38000-123-45-16', 'Сало та частник', '../images/contact_list/005.png'),
(6, 'Николай', '+38016-183-45-68', 'Хочу на работу', '../images/contact_list/006.png'),
(7, 'Петрическу', '+38000-123-45-46', 'Люблю котиков', '../images/contact_list/007.png'),
(8, 'Петрович', '+38000-166-45-46', 'Круть', '../images/contact_list/008.png'),
(9, 'Марина', '+38030-166-45-46', 'Где тут басейн?', '../images/contact_list/009.png'),
(10, 'Иван', '+38000-123-89-16', 'А-БА-БА-ГА-ЛА-МА-ГА', '../images/contact_list/010.png');

-- --------------------------------------------------------

--
-- Структура таблицы `favouriteday`
--

CREATE TABLE `favouriteday` (
  `id` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `favouriteday`
--

INSERT INTO `favouriteday` (`id`, `day`, `month`, `year`) VALUES
(1, 2, 10, 1965),
(2, 0, 1111, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `name` varchar(300) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `offers`
--

INSERT INTO `offers` (`id`, `name`) VALUES
(1, 'шампунь'),
(2, 'порошок'),
(3, 'мыло'),
(4, 'зубная паста'),
(5, 'гель для душа'),
(6, 'зубная щетка');

-- --------------------------------------------------------

--
-- Структура таблицы `operators`
--

CREATE TABLE `operators` (
  `id` int(11) NOT NULL,
  `name` varchar(300) COLLATE utf8_bin NOT NULL,
  `fio` varchar(300) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `operators`
--

INSERT INTO `operators` (`id`, `name`, `fio`) VALUES
(10, 'оператор1', 'Миронов Сергей Игоревич'),
(12, 'оператор2', 'Шевченко Андрей Иванович'),
(17, 'оператор3', 'Иванюк Андрей Петрович');

-- --------------------------------------------------------

--
-- Структура таблицы `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `offer_id` int(11) NOT NULL,
  `price` double NOT NULL,
  `count` int(11) NOT NULL,
  `operator_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Дамп данных таблицы `requests`
--

INSERT INTO `requests` (`id`, `offer_id`, `price`, `count`, `operator_id`) VALUES
(1, 1, 50, 1, 10),
(2, 2, 200, 4, 12),
(3, 3, 400, 6, 12),
(4, 5, 600, 3, 17),
(5, 5, 600, 3, 17),
(6, 3, 400, 6, 12),
(7, 4, 1000, 10, 10),
(8, 3, 400, 6, 12),
(9, 1, 50, 1, 17);

-- --------------------------------------------------------

--
-- Структура таблицы `school_class`
--

CREATE TABLE `school_class` (
  `id` int(10) NOT NULL,
  `class` char(50) NOT NULL,
  `id_subject` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `school_class`
--

INSERT INTO `school_class` (`id`, `class`, `id_subject`) VALUES
(1, '1-1', 2),
(2, '1-2', 3),
(3, '1-3', 4),
(4, '2-1', 5),
(5, '2-2', 6),
(6, '2-3', 7),
(7, '3-1', 8),
(8, '3-2', 9),
(9, '3-3', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `school_subject`
--

CREATE TABLE `school_subject` (
  `id` int(10) NOT NULL,
  `subjects` char(50) NOT NULL,
  `id_teacher` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `school_subject`
--

INSERT INTO `school_subject` (`id`, `subjects`, `id_teacher`) VALUES
(1, 'Физика', 8),
(2, 'Химия', 7),
(3, 'Математика', 6),
(4, 'Биология', 5),
(5, 'Язык, письмо', 4),
(6, 'литература', 3),
(7, 'История', 2),
(8, 'География', 1),
(9, 'Ин.яз', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `school_teacher`
--

CREATE TABLE `school_teacher` (
  `id` int(10) NOT NULL,
  `teachers` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `school_teacher`
--

INSERT INTO `school_teacher` (`id`, `teachers`) VALUES
(1, 'Учитель 1'),
(2, 'Учитель 2'),
(3, 'Учитель 3'),
(4, 'Учитель 4'),
(5, 'Учитель 5'),
(6, 'Учитель 6'),
(7, 'Учитель 7'),
(8, 'Учитель 8'),
(9, 'Учитель 9');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`, `age`, `email`) VALUES
(1, 'Ніколай', 60, 'asd@тест.укр'),
(2, 'гы', 6, 'asd@тест.укр'),
(3, 'name2', 26, 'asd@ffg.net'),
(4, 'Іванко', 0, 'asd@тест.укр'),
(5, 'Моє ім\'я', 46, 'asd@тест.укр'),
(6, 'Франко', 16, 'mmкdf@fк1fg.net'),
(7, 'Ніколай Іванович', 35, 'mmdf@ffg.net'),
(8, 'Ніколай Миколайович', 37, '1222mmdf@ffg.net'),
(9, 'Миолайчук', 17, 'mmdf@fк1fg.net'),
(10, 'Йцукен', 35, '3334@sdf.df');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `email`) VALUES
(1, 'user1', '1111', 'qwe@qwe.qwe'),
(2, 'user2', '2222', 'qwe@qwe.qwe'),
(3, 'user3', '3333', 'qwe@qwe.qwe');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `contact_list`
--
ALTER TABLE `contact_list`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `favouriteday`
--
ALTER TABLE `favouriteday`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `operators`
--
ALTER TABLE `operators`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offer_id` (`offer_id`),
  ADD KEY `operator_id` (`operator_id`);

--
-- Индексы таблицы `school_class`
--
ALTER TABLE `school_class`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `school_subject`
--
ALTER TABLE `school_subject`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `school_teacher`
--
ALTER TABLE `school_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `contact_list`
--
ALTER TABLE `contact_list`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `favouriteday`
--
ALTER TABLE `favouriteday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `operators`
--
ALTER TABLE `operators`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT для таблицы `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`offer_id`) REFERENCES `offers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`operator_id`) REFERENCES `operators` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
