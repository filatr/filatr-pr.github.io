-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 22 2019 г., 12:20
-- Версия сервера: 10.1.38-MariaDB
-- Версия PHP: 7.2.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `new_bd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `favouriteday`
--

CREATE TABLE `favouriteday` (
  `id` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `favouriteday`
--

INSERT INTO `favouriteday` (`id`, `day`, `month`, `year`) VALUES
(1, 2, 10, 1965);

-- --------------------------------------------------------

--
-- Структура таблицы `school_class`
--

CREATE TABLE `school_class` (
  `id` int(10) NOT NULL,
  `class` char(50) NOT NULL,
  `id_subject` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `school_class`
--

INSERT INTO `school_class` (`id`, `class`, `id_subject`) VALUES
(1, '1-1', 2),
(2, '1-2', 3),
(3, '1-3', 4),
(4, '2-1', 5),
(5, '2-2', 6),
(6, '2-3', 7),
(7, '3-1', 8),
(8, '3-2', 9),
(9, '3-3', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `school_subject`
--

CREATE TABLE `school_subject` (
  `id` int(10) NOT NULL,
  `subjects` char(50) NOT NULL,
  `id_teacher` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `school_subject`
--

INSERT INTO `school_subject` (`id`, `subjects`, `id_teacher`) VALUES
(1, 'Физика', 8),
(2, 'Химия', 7),
(3, 'Математика', 6),
(4, 'Биология', 5),
(5, 'Язык, письмо', 4),
(6, 'литература', 3),
(7, 'История', 2),
(8, 'География', 1),
(9, 'Ин.яз', 9);

-- --------------------------------------------------------

--
-- Структура таблицы `school_teacher`
--

CREATE TABLE `school_teacher` (
  `id` int(10) NOT NULL,
  `teachers` char(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `school_teacher`
--

INSERT INTO `school_teacher` (`id`, `teachers`) VALUES
(1, 'Учитель 1'),
(2, 'Учитель 2'),
(3, 'Учитель 3'),
(4, 'Учитель 4'),
(5, 'Учитель 5'),
(6, 'Учитель 6'),
(7, 'Учитель 7'),
(8, 'Учитель 8'),
(9, 'Учитель 9');

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`id`, `name`, `age`, `email`) VALUES
(1, 'Ніколай', 62, 'memdf@ffge.net'),
(2, 'гы', 6, 'asd@тест.укр'),
(3, 'name2', 26, 'asd@ffg.net'),
(4, 'Іванко', 0, 'asd@тест.укр'),
(5, 'Моє ім\'я', 46, 'asd@тест.укр'),
(6, 'тест 2', 16, 'asd@тест.укр'),
(7, 'Ніколай Іванович', 35, 'mmdf@ffg.net');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `login` int(11) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `favouriteday`
--
ALTER TABLE `favouriteday`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `school_class`
--
ALTER TABLE `school_class`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `school_subject`
--
ALTER TABLE `school_subject`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `school_teacher`
--
ALTER TABLE `school_teacher`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `favouriteday`
--
ALTER TABLE `favouriteday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
